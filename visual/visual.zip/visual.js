var canvas = document.getElementById("canvas");
var context = canvas.getContext("2d");

var units = 8; // 1 foot is 4 px
var drop = 35; 

var offsetx = 30;
var offsety = 30;

function drawLine(x1, y1, x2, y2) {
	context.moveTo(x1, y1);
	context.lineTo(x2, y2);
	context.stroke();
}
function wrapText(context, text, x, y, maxWidth, lineHeight) {
	var cars = text.split("\n");

	for (var ii = 0; ii < cars.length; ii++) {

		var line = "";
		var words = cars[ii].split(" ");

		for (var n = 0; n < words.length; n++) {
			var testLine = line + words[n] + " ";
			var metrics = context.measureText(testLine);
			var testWidth = metrics.width;

			if (testWidth > maxWidth) {
				context.fillText(line, x, y);
				line = words[n] + " ";
				y += lineHeight;
			}
			else {
				line = testLine;
			}
		}

		context.fillText(line, x, y);
		y += lineHeight;
	}
}

function isInside(x, y, x1, y1, w, h) {
	return x > x1 && x < x1 + w && y > y1 && y < y1+h;
}



function drawText(x, y, font, text) {
	context.font = font;
	wrapText(context, text, x, y, 500,15);
}
function drawPoint(x, y, rad) {
	context.arc(x, y, rad, 0, 2 * Math.PI);
	context.fill();
}
var droplevel = 0;
function drawTree(tree, ox, oy) {
	var dx = tree.dist*units;
	drawLine(ox, oy, ox+dx, oy);
	drawPoint(ox, oy, 2);
	var labels = "";
	for(var i = 0; i < tree.ends.length; i++) {
		labels += tree.ends[i].id + "\n";
	}
	drawText(ox + dx + 5, oy + 15, "12px Georgia", labels);
	drawText(ox + dx/2, oy + 15, "12px Georgia", tree.dist + "'");
	drawPoint(ox+dx, oy, 2);
	ox += dx;

	for(var i = 0; i < tree.children.length; i++) {
		if(i != 0) {
			var py = oy;
			droplevel++;
			oy = offsety + droplevel*drop;
			drawLine(ox, py, ox, oy);
		}
		drawTree(tree.children[i], ox, oy);
	}
}
function LoadJSON(data) {
	drawTree(data, offsetx, offsety);
}
